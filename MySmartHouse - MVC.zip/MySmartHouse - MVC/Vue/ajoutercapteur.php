<?php
    include('commun.php');


    $entete = entete();
    $contenu = ajoutercapteur();
    $pied = pied();

    include '../gabarit.php';
?>
