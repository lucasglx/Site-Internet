<?php
    include('commun.php');

    $entete = entete();
    $contenu = quisommesnous();
    $pied = pied();

    include '../gabarit.php';

?>
