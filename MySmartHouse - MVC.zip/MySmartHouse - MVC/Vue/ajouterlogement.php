<?php
    require ("Modele/utilisateur.php");

    $user= getUserData();
    $entete = entete();
    $contenu = ajouterlogement();
    $pied = pied();

    include '../gabarit.php';
  
?>
