<?php

    include 'commun.php';

    $entete = entete();
    $contenu = editer_profil();
    $pied = pied();

    include '../gabarit.php';
?>

