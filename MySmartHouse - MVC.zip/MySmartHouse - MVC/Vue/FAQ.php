<?php
    include('commun.php');
   
    $entete = entete();
    $contenu = FAQ();
    $pied = pied();

    include '../gabarit.php';
?>
