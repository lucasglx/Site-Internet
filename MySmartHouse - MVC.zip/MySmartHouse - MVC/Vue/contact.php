<?php
    include('commun.php');


    $entete = entete();
    $contenu = contact();
    $pied = pied();

    include '../gabarit.php';
?>
