<?php
    include('commun.php');
    $titre = "MySmartHouse";

    $entete = entete();
    $contenu = contact();
    $pied = pied();

    include '../gabarit.php';
?>
