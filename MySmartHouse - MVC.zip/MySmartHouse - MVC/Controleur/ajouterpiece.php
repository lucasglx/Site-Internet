<?php

if(isset($_GET['cible']) && $_GET['cible']=="ajouterpiece") { 

if(isset($_SESSION['userID'])) {
    include ('Modele/logement.php');
    $logement = getUserLogement();
    
if(isset($_POST['formpiece'])) {
    $nom = htmlspecialchars($_POST['nom']);
    $superficie = htmlspecialchars($_POST['superficie']);
    $n_piece = htmlspecialchars($_POST['n_piece']);
    

   if(!empty($_POST['nom']) AND !empty($_POST['superficie']) AND !empty($_POST['n_piece'])) {
      $nomlength = strlen($nom);
      if($nomlength <= 255) {
            include ("Modele/logement.php");
            $insertpiece($db,$nom,$superficie);
            echo"<script>alert('Votre logement a bien été créé');document.location.href='index.php?ajoutercapteur'</script>";


      }
       else
        {
            echo"<script>alert('Le nom de votre pièce ne doit pas dépasser 255 caractères !');document.location.href='Vue/ajouterpiece.php'</script>";
        }
   }
        else
        {
            echo"<script>alert('Tous les champs doivent être completés !') document.location.href='Vue/ajouterpiece.php'</script>";
        }
}
}
}
?>