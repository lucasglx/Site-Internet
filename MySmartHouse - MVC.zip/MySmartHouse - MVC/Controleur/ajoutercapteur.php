<?php

if(isset($_GET['cible']) && $_GET['cible']=="ajoutercapteur") { 
if(isset($_POST['nom'])
   AND isset($_POST['type'])
   AND isset($_POST['numero_serie'])
   AND $_POST['nom']!=""
   AND $_POST['type']!=""
   AND $_POST['numero_serie']!="")
{
    
    ajoutercapteur($_POST['nom'],$_POST['type'],$_POST['numero_serie'],$db);
    echo"<script>alert('Votre capteur a été ajouté avec succès')</script>";

}
else
{
    echo"<script>alert('Tous les champs ne sont pas remplis');</script>";
}

    echo"?<script>document.location.href='index.php?cible=ajoutercapteur'</script>";
    
}
?>