<?php

if(isset($_GET['cible']) && $_GET['cible']=="ajoutercapteur") {
    var_dump($_POST);
echo "toto1";

if(isset($_SESSION['userID'])) {
    include ('Modele/gestioncapteur.php');
var_dump($_POST);
echo "toto2";

    
//if(isset($_POST['formcapteur'])) {
if(isset($_POST['formpiece'])) {

    var_dump($_POST);
echo "toto3";
//    exit(0);
    if(isset($_POST['piece'])
       AND isset($_POST['type'])
       AND isset($_POST['nserie'])
       AND $_POST['piece']!=""
       AND $_POST['type']!=""
       AND $_POST['nserie']!="")
    {
var_dump($_POST);
echo "toto4";

        insertcapteur($_POST['piece'],$_POST['type'],$_POST['nserie']);
        
        echo"<script>alert('Votre capteur a été ajouté avec succès');document.location.href='index.php';</script>";

    }
    else
    {
        echo"<script>alert('Tous les champs ne sont pas remplis');document.location.href='Vue/ajoutercapteur.php';</script>";
    }

    echo"?<script>document.location.href='index.php?cible=ajoutercapteur'</script>";
    
}
}
}

var_dump($_POST);
echo "toto";
?>