
<?php

 function ajoutercapteur($nom,$type,$numero_serie,$db)
    {
        $req = $db->prepare('INSERT INTO capteur(piece,type,numero_serie) VALUES(?, ?, ?)');
        $req->execute(array('piece' => $nom,'type' => $type,'numero_serie' => $numero_serie));
    }

function getcapteurs($db)
{
    $req = $db->query('SELECT * FROM capteur');
    return $req;
}

function supprimercapteur($numero_serie, $db)
{
    $req = $db->prepare('DELETE FROM capteur WHERE numero_serie LIKE :id');
    $req -> execute(array('id' => $numero_serie));
}
?>

