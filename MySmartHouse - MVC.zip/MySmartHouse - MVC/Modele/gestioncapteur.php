
<?php

 function insertcapteur($piece,$type,$numero_serie)
    {
        require("connexion.php");
        $req = $db->prepare('INSERT INTO capteur(id_piece,type,numero_serie) VALUES(?, ?, ?)');
        $req->execute(array($piece, $type,$numero_serie));
        return $req;
    }

function getcapteurs($db)
{
    $req = $db->query('SELECT * FROM capteur');
    return $req;
}

function supprimercapteur($numero_serie, $db)
{
    $req = $db->prepare('DELETE FROM capteur WHERE numero_serie LIKE :id');
    $req -> execute(array('id' => $numero_serie));
}
?>

