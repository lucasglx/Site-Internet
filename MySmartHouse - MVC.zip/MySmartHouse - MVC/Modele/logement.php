<?php
function getUserData(){
        require("connexion.php");
        $requser = $db -> prepare ('SELECT * FROM utilisateur WHERE id =?');
        $requser -> execute(array($_SESSION ['userID']));
        $user = $requser -> fetch();
        return $user;
}

function insertlogement ($db, $nom, $superfie, $n_piece){
    
    $insertlgmnt = $bdd->prepare("INSERT INTO logement (nom, superficie, n_piece) VALUES(?, ?, ?)");
    $insertlgmnt->execute(array($nom, $superficie, $n_piece));
    return $inserlgmnt;
}

function insertpiece ($db, $nom, $superfie){
    
    $insertpiece = $bdd->prepare("INSERT INTO logement (nom, superficie) VALUES(?, ?)");
    $insertpiece->execute(array($nom, $superficie));
    return $inserpiece;
}
function getUserLogement(){
        require("connexion.php");
        $reqlogement = $db -> prepare ('SELECT * FROM logement WHERE id =?');
        $reqlogement -> execute(array($_SESSION ['userID']));
        $logement = $reqlogement -> fetch();
        return $logement;
}


?>