<?php
    $dbname = "bdd-msh";
    $host='localhost';
    $user='root';
    $pass=' ';

    $bdd = new PDO('mysql:host=localhost;dbname=bdd-msh;charset=utf8', 'root', '');



    $bdd->query("SET NAMES UTF8");
?>