 <?php
    require("connexion.php");

    // fonction qui cherche le mot de passe d'un utilisateur avec un identifiant dans la base de données
    function ajouterpiece($bdd,$nom,$superficie,$n_capteurs){



 $sql = $bdd-> prepare('INSERT INTO pièces(nom, superficie, n_capteurs) VALUES (:nom, :superficie, :n_capteurs)');

    $sql-> execute (array(
        "nom"=>$nom,
        "superficie"=>$superficie,
        "n_capteurs"=>$n_capteurs
      ));

    
?>

