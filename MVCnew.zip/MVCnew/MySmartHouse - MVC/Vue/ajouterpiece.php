<?php

    include 'commun.php';

    $entete = entete();
    $contenu = ajouterpiece();
    $pied = pied();

    include '../gabarit.php';
?>

