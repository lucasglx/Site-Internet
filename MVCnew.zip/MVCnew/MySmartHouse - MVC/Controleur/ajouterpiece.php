<?php
$bdd = new PDO('mysql:host=localhost;dbname=bdd-msh;charset=utf8', 'root', '');



if (!empty($_POST['nom']) && !empty($_POST['superficie']) && !empty($_POST['n_capteurs'])) {
    $nom = htmlspecialchars($_POST['nom']);
    $superficie = htmlspecialchars($_POST['superficie']);
    $n_capteurs = htmlspecialchars($_POST['n_capteurs']); 
    echo "<script>alert('Pièce ajoutée !');document.location.href='http://localhost/MVCnew/MySmartHouse%20-%20MVC/index.php?cible=verif;</script>";
}  

else {

  echo "<script>alert('Veuillez remplir tous les champs')</script>";

}

?>