<?php

// Génère le code HTML du formulaire de connexion
function connexion(){

    ob_start();
    ?>
        <fieldset>
            <form method="POST" action="index.php?cible=verif">
                <legend>Connexion</legend> <br>
        
                <p>
                    <label for="email">Adresse mail ou pseudo :
                    </label><br>
                    <input type="text" name="mail" placeholder="Mail " />
                
                
                <br>
                    <label for="password">Mot de passe :
                    </label><br>
                    <input type="password" name="mdp" placeholder="Mot de passe " />
                
                
                <p>
                    <input type="submit" value="Se connecter"/>
                </p>
                
                <p>
                    <a href="http://localhost:8888/MySmartHouse%20-%20MVC/Vue/inscription.php">Première connexion ?</a>
                </p>
                  
                </form>
                <?php
                    if(isset($erreur)) {
                    echo '<font color="red">'.$erreur."</font>";
                    }
                ?>
                
            </fieldset>
    <?php
    $formulaire = ob_get_clean();
    return $formulaire;
}

function valeurcapteur($capteur)
{
	
	ob_start();
	?>
        <h1>Modifier la valeur d'un capteur</h1>
         <br /><br />               
		 <fieldset>
         <form method="POST" action="http://localhost:8888/MySmartHouse%20-%20MVC/index.php?cible=changervaleur">
			<table>
               <tr>
                  <td align="right">Nom du logement :</td>
                  <td align="left"><?=$capteur[0]["nomlogement"]?></td>
                </tr>

				<tr>
                  <td align="right">Nom de la pièce :</td>
                  <td align="left"><?=$capteur[0]["nompiece"]?></td>
                </tr>

                <tr>
                  <td align="right">Type de capteur :</td>
				  <td>
				  <td align="left"><?=$capteur[0]["typecapteur"]?></td>
                </tr>

                <tr> 
                  <td align="right">Valeur du capteur :
                  <td align="left">
                     <input type="text" placeholder="values" id="valeur" name="valeur" value="<?=$capteur[0]["valeur"]?>">
                  </td>
                </tr>

                <tr>
                  <td></td>
                  <td align="center">
                     <br />
                        <input type="button" value="Retour" onclick="history.go(-1)"/>
                        <input type="submit" name="formvaleur" value="Valider" />
                  </td>
               </tr>
                </table>
				<input type="hidden" value="<?=$capteur[0]["id"]?>" name="id" id="id"/>
            </form>
            </fieldset>
 	<?php
    $affiche = ob_get_clean();
    return $affiche;
}

function affichagecapteur($capteurs)
{
	ob_start();?>
	<table>
		<tr>
			<th>Logement</th>
			<th>Pièce</th>
			<th>Type Capteur</th>
			<th>Valeur</th>
		</tr>
		<?php
             foreach ($capteurs as $key => $value){?>
				 <tr>
				 <td> <a href="http://localhost:8888/MySmartHouse%20-%20MVC/index.php?cible=changervaleur&id=<?=$value[0]?>"><?=$value[3]?></a></td>
				 <td> <?=$value[4]?></td>
				 <td> <?=$value[1]?></td>
				 <td> <?php
				 switch($value[1])
				{
				 case 'Lumière':
				  if ($value[2]==1)
					  echo "ON";
				  else
					  echo "OFF";
				  break;

				 case 'Température':
					echo $value[2];
					echo " °C";
				  break;

				 case 'Humidité':
					echo $value[2];
					echo " %";
				  break;

				 default :
					echo "vide";
				  break;
				}

				 ?></td>
				 </tr>
			 <?php 
			 }
		?>
	</table>
	<?php
    $affiche = ob_get_clean();
    return $affiche;
}

//Génère le code HTML de l'inscription
function forminscription(){
    ob_start();
    ?>
        <div class="bienvenue">
               
            <h1>Inscription</h1>
        </div>
         <br/>
             <fieldset>
                    <form method="POST" action="http://localhost:8888/MySmartHouse%20-%20MVC/index.php?cible=verifinscription">
                <tr>
                    <td align="right">
                     <label for="pseudo">Pseudo :</label>
                    </td>
                    <td>
                     <input type="text" placeholder="Votre pseudo" id="pseudo" name="pseudo" value="<?php if(isset($pseudo)) { echo $pseudo; } ?>" />
                    </td>
                </tr>
                
                <tr>
                  <td align="right">
                     <label for="birth">Date de naissance :</label>
                  </td>
                  <td>
                     <input type="date" placeholder="Votre date de naissance" id="birth" name="birth" value="<?php if(isset($birth)) { echo $birth; } ?>" />
                  </td>
                </tr>
                
                <tr>
                  <td align="right">
                     <label for="surname">Prénom :</label>
                  </td>
                  <td>
                     <input type="text" placeholder="Votre prénom" id="prénom" name="prénom" value="<?php if(isset($prénom)) { echo $prénom; } ?>" />
                  </td>
                </tr>
                
                <tr>
                  <td align="right">
                     <label for="name">Nom :</label>
                  </td>
                  <td>
                     <input type="text" placeholder="Votre nom" id="nom" name="nom" value="<?php if(isset($nom)) { echo $nom; } ?>" />
                  </td>
                </tr>
                
                <tr>
                  <td align="right">
                     <label for="address">Adresse :</label>
                  </td>
                  <td>
                     <input type="text" placeholder="Votre adresse" id="adresse" name="adresse" value="<?php if(isset($address)) { echo $address; } ?>" />
                  </td>
                </tr>
                
                <tr>
                  <td align="right">
                     <label for="city">Ville :</label>
                  </td>
                  <td>
                     <input type="text" placeholder="Votre ville" id="ville" name="ville" value="<?php if(isset($city)) { echo $city; } ?>" />
                  </td>
                </tr>
                
                <tr>
                  <td align="right">
                     <label for="zip">Code postal :</label>
                  </td>
                  <td>
                     <input type="tel" placeholder="Votre code postal" id="code_postal" name="code_postal" value="<?php if(isset($zip)) { echo $zip; } ?>" />
                  </td>
                </tr>
                
                <tr>
                  <td align="right">
                     <label for="country">Pays :</label>
                  </td>
                  <td>
                     <input type="text" placeholder="Votre pays" id="pays" name="pays" value="<?php if(isset($country)) { echo $country; } ?>" />
                  </td>
                </tr>
                
                <tr>
                  <td align="right">
                     <label for="phone">Téléphone :</label>
                  </td>
                  <td>
                     <input type="tel" placeholder="Votre n° de téléphone" id="numero_tel" name="numero_tel" value="<?php if(isset($phone)) { echo $phone; } ?>" />
                  </td>
                </tr>
                
               <tr>
                  <td align="right">
                     <label for="mail">Mail :</label>
                  </td>
                  <td>
                     <input type="email" placeholder="Votre mail" id="mail" name="mail" value="<?php if(isset($mail)) { echo $mail; } ?>" />
                  </td>
               </tr>
                
               <tr>
                  <td align="right">
                     <label for="mail2">Confirmation du mail :</label>
                  </td>
                  <td>
                     <input type="email" placeholder="Confirmez votre mail" id="mail2" name="mail2" value="<?php if(isset($mail2)) { echo $mail2; } ?>" />
                  </td>
               </tr>
                
               <tr>
                  <td align="right">
                     <label for="mdp">Mot de passe :</label>
                  </td>
                  <td>
                     <input type="password" placeholder="Votre mot de passe" id="mdp" name="mdp" />
                  </td>
               </tr>
                
               <tr>
                  <td align="right">
                     <label for="mdp2">Confirmation du mot de passe :</label>
                  </td>
                  <td>
                     <input type="password" placeholder="Confirmez votre mdp" id="mdp2" name="mdp2" />
                  </td>
               </tr>
                
               <tr>
                  <td></td>
                  <td align="center">
                     <br />
                     <input type="submit" name="forminscription" value="Je m'inscris"/>
                  </td>
               </tr>
            </form>
                 
         <?php
         if(isset($erreur)) {
            echo '<font color="red">'.$erreur."</font>";
         }
         ?>
    </fieldset>

    <?php
    $forminscription = ob_get_clean();
    return $forminscription;
}


// Génère le code HTML de l'entête
function entete(){
    ob_start();
    ?>

        <div class="topnav">
            <p><img src= "http://localhost:8888/MySmartHouse%20-%20MVC/img/logomysmarthousepetit.png" class="logoentreprise" alt="Logo entreprise"/></p>
            <a href="http://localhost:8888/MySmartHouse%20-%20MVC/index.php?cible=accueil">Accueil</a>
            <a href="http://localhost:8888/MySmartHouse%20-%20MVC/Vue/qui_sommes_nous.php">Qui sommes-nous ?</a>
            <a href="http://localhost:8888/MySmartHouse%20-%20MVC/Vue/contact.php">Contact</a>
            <a href="http://localhost:8888/MySmartHouse%20-%20MVC/Vue/FAQ.php">FAQ</a>
            <?php
            if (isset ($_SESSION["userID"]))
            {
                echo '<a href="index.php?cible=verifedition">Editer son profil</a>';
                echo '<a href="index.php?cible=deconnexion">Déconnexion</a>';
            }
            ?>
        </div>
    <?php
    $entete = ob_get_clean();
    return $entete;
}


// Génère le code HTML du pied de page
// même code pour toutes les pages
function pied(){
    ob_start();
    ?>
        <span style="font-style:italic;">MySmartHouse</span>
    <?php
    $pied = ob_get_clean();
    return $pied;
}

function quisommesnous(){
    ob_start();
    ?>
            <h1 style="text-align: center">PRESENTATION DE L'ENTREPRISE</h1> <br>

            
            <h2 style="color: #2874A6"><img src="http://localhost:8888/MySmartHouse%20-%20MVC/img/historique.jpg" class="historique" alt="Livre" align="top" height="40" width="40"/><I>Historique</I></h2> 
            
            <p style="font-size: 17">MySmartHouse est une entreprise grandissante qui a été créée en 2017. Issue d'une équipe d'étudiants pluriculturels de l'ISEP, elle a su trouvé au travers de son premier client DOMISEP un défit à la hauteur des attentes de l'equipe qui en est à la tête.
            </p> 
            <br> 

            <h2 style="color:#2874A6"><img src="http://localhost:8888/MySmartHouse%20-%20MVC/img/Objectif.jpg" class="objectif" alt="objectif" align="top" height="40" width="40"/><I>Objectif</I></h2>
            
            <p style="font-size: 17">Fermez les yeux, et imaginez un monde où votre maison répond à vos besoins. Luminosité, température, humidité, sécurité... Tout est sous votre contrôle et ce en un seul un clic ! MySmartHouse est un outil qui vous permettra d’être connecté à votre domicile depuis n’importe où et à n’importe quel moment. Grâce à notre base de données et à notre plateforme Web MySmartHouse.fr, le client pourra avoir accès au contrôle de sa maison à distance.
            </p>
            <br> 

            <h2 style="color:#2874A6"><img src="http://localhost:8888/MySmartHouse%20-%20MVC/img/equipe.jpg" class="equipe" alt="bonhomme" align="top" height="40" width="40"/>  <I>Derrière MySmartHouse ?</I></h2>
            
           <br>
            
            <p style="font-size:17"><img src="http://localhost:8888/MySmartHouse%20-%20MVC/img/lucas.png" class="photo" alt="Photo de Lucas" align="middle" height="100" width="100"/> Lucas Gallix, 22ans : <I>"Les bases de données, ça me connait ! " </I>
            </p>
            <br>
            
            
            
            <p style="font-size:17"><img src="http://localhost:8888/MySmartHouse%20-%20MVC/img/bouchra.png" class="photo" alt="Photo de Bouchra" align="middle" height="100" width="100"/> Bouchra Djelali, 20 ans : <I>"Vos besoins sont notre priorité."</I>
            </p>
            <br>
            
        
            <p style="font-size:17"><img src="http://localhost:8888/MySmartHouse%20-%20MVC/img/julie.png" class="photo" alt="Photo de Julie" align="middle" height="100" width="100"/> Julie Lembourg, 20 ans : <I>"La coopération avant tout." </I>
            </p>
            
           <br>
            
            <p style="font-size:17"><img src="http://localhost:8888/MySmartHouse%20-%20MVC/img/yann.png" class="photo" alt="Photo de Yann" align="middle" height="100" width="100"/>Yann De Parscau, 22 ans :
             <I>"L'informatique, c'est l'avenir."</I>
            </p>
            
           <br>
            
            <p style="font-size:17"><img src="http://localhost:8888/MySmartHouse%20-%20MVC/img/sara.png" class="photo" alt="Photo de Sara" align="middle" height="100" width="100"/> Sara Atine, 21 ans : <I>"L'automatisation n'est pas qu'une simple option."</I>
            </p>
            
            <br>
            
            <p style="font-size:17"><img src="http://localhost:8888/MySmartHouse%20-%20MVC/img/paul-emile.png" class="photo" alt="Photo de Paul-emile" align="middle" height="100" width="100"/> Paul-Emile Chayet, 21 ans :<I>"" </I></p>
            
            <br>
            
            <p style="font-size:17"><img src="http://localhost:8888/MySmartHouse%20-%20MVC/img/paul.png" class="photo" alt="Photo de Paul" align="middle" height="100" width="100"/> Paul Chasseuil, 21 ans : <I>"A demain !"</I>
            </p>
            
            <?php
            $quisommesnous = ob_get_clean();
            return $quisommesnous;
    
}

function contact(){
    ob_start();
    ?>
            <div class="contacteznous">
        
            <h1 style="text-align:center">CONTACTEZ-NOUS</h1><br><br>
            </div>

                <fieldset>
                <div class="logocontact">
                <p><a href="mailto:mysmarthouse.contact@gmail.com" class="logoemail" target="_blank"><img src="http://localhost:8888/MySmartHouse%20-%20MVC/img/email.jpg" alt="Email"><p>Envoyez un mail</p></a>
                <p>
                </div>   
                <div class="logocontact">
                <p><img src="http://localhost:8888/MySmartHouse%20-%20MVC/img/telephone.jpg" class="logotelephone" alt="telephone"/></p>
                <p><I><B>+33 1 23 45 67 89</B></I></p>
                </div>
                <div class="logocontact">
                <p><a href="https://www.facebook.com/My-Smart-House-1021275438007096/?fref=ts" class="logofacebook" target="_blank"><img src="http://localhost:8888/MySmartHouse%20-%20MVC/img/facebook.png" alt="Facebook" ><p>
                <p>Likez notre page</p></a>
               </div>
               </fieldset>
               <br>
               <br>
               <br>
               <h1 style="text-align:center;">TROUVEZ-NOUS FACILEMENT</h1><br>
               <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d656.6883495279876!2d2.280302766448461!3d48.82476644102272!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xe0d3eb2ad501cb27!2sISEP!5e0!3m2!1sfr!2sfr!4v1494930808024" width="900" height="600" frameborder="0"></iframe>
            <br><br><br>
            <?php
            $contact = ob_get_clean();
            return $contact;
    
}

function FAQ(){
    ob_start();
    ?>
           <div class="foireauxquestions">
            <p><img src= "http://localhost:8888/MySmartHouse%20-%20MVC/img/logomysmarthousepetit.png" class="logoentreprisefaq" alt="Logo entreprise"  /></p>
            <h1>FAQ</h1>
        </div>
            
        <fieldset>
                <legend>Foire aux questions</legend>

        <dl>
            <dt>Question 1 : Comment retrouver l'identifiant et le mot de passe de mon compte ?</dt>
            <dd>&hellip; blablabla &hellip;</dd>
            <dt>Question 2 : Comment installer mes capteurs?</dt>
            <dd>&hellip; blablabla &hellip;</dd>
            <dt>Question 3 : Comment trouver les numéros de série de mes capteurs?</dt>
            <dd>&hellip; blablabla &hellip;</dd>
            <dt>Question 4 : Où tester les produits MySmartHouse?</dt>
            <dd>&hellip; blablabla &hellip;</dd>
        </dl>


        <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
        <script type="text/javascript">

        $(document).ready(function() {

            $("dd").hide();
            $("dt").css("cursor", "pointer");
            $("dt").click(function() {
        
            if($(this).next().is(":visible") == false) {
                $("dd").slideUp();
                $(this).next().slideDown();
            }
            });
        });

    </script>
        </fieldset>
            <?php
            $FAQ = ob_get_clean();
            return $FAQ;
    
}

function accueil_connecte(){
    ob_start();
    ?>
        <a href="http://localhost:8888/MySmartHouse%20-%20MVC/index.php?cible=ajoutercapteur"> Ajouter capteur</a>
        <a href="http://localhost:8888/MySmartHouse%20-%20MVC/index.php?cible=ajouterpiece"> Ajouter piece</a>
        <a href="http://localhost:8888/MySmartHouse%20-%20MVC/index.php?cible=ajouterlogement"> Ajouter logement</a>
        <a href="http://localhost:8888/MySmartHouse%20-%20MVC/index.php?cible=affichercapteur"> Affichage des Capteurs</a>
        <div class="menu">
            <div class="température">
        	   <img src="img/temperature.png" />
                <figcaption>Température</figcaption>
            </div>
            <div class="caméra">
        	   <img src="img/camera.png" />
                <figcaption>Caméra</figcaption>
-
            </div>
            <div class="volet">
        	   <img src="img/volet.png" />
                <figcaption>Volet</figcaption>
            </div>
            <div class="mode">
                <img src="img/mode.png" />
                <figcaption>Paramètrer les modes</figcaption>
            </div>
        </div>
        <div class="contenu">
                <div class="option economie">
                    <img src="img/power.png" class="power" height="42" width="42">
                    <h1> Mode Economie </h1>
                    <h3>Faites des économies tout en pensant à la planète</h3>
                    <div class="switch">
                        <input id="cmn-toggle-1" class="cmn-toggle cmn-toggle-round" type="checkbox">
                        <label for="cmn-toggle-1"></label>
                    </div>
                </div>
                <div class="option voyage">
                    <img src="img/avion.png" class="avion" height="42" width="42">
                    <h1> Mode Voyage </h1>
                    <h3>Minimisez votre consomation d'énergie</h3>
                    <div class="switch">
                        <input id="cmn-toggle-2" class="cmn-toggle cmn-toggle-round" type="checkbox">
                        <label for="cmn-toggle-2"></label>
                    </div>
                </div>
                <div class="option secutite">
                    <img src="img/cadenas.png" class="cadenas" height="42" width="42">
                    <h1> Mode Sécurité </h1>
                    <h3>Quittez votre domicile l'esprit tranquille</h3>
                    <div class="switch">
                        <input id="cmn-toggle-3" class="cmn-toggle cmn-toggle-round" type="checkbox">
                        <label for="cmn-toggle-3"></label>
                    </div>                   
                </div>
                <div class="option automatique">
                    <img src="img/ampoule.png" class="ampoule" height="42" width="42">
                    <h1> Gestion automatique de luminosité </h1>
                    <h3>S'adapte à vos besoins et évolue en temps réel selon votre environnement</h3>
                     <div class="switch">
                        <input id="cmn-toggle-4" class="cmn-toggle cmn-toggle-round" type="checkbox">
                        <label for="cmn-toggle-4"></label>
                    </div>                   
                </div>
            
        </div>

            <?php
            $accueil_connecte = ob_get_clean();
            return $accueil_connecte;
    
}

function editer_profil($user){
    ob_start();
    ?>
    
        <h1 style="text-align: center">EDITER SON PROFIL</h1> <br> <br>
            <fieldset>
            <form method="POST" action="http://localhost:8888/MySmartHouse%20-%20MVC/index.php?cible=verifedition" enctype="multipart/form-data">  
             
            <table>
            <br>
            <tr>
               <td align="left">
               <label>Nouveau pseudo :</label>
               </td>
               <td>
               <input type="text" name="newpseudo" placeholder="Pseudo" value="<?php echo $user['pseudo']; ?>" />
               </td>
            </tr>

            <tr>
               <td align="left">
               <label>Nouveau mail :</label>
               </td>
               <td>
               <input type="text" name="newmail" placeholder="Mail" value ="<?php echo $user['mail']; ?>" />
               </td>

            <tr>
               <td align="left">
               <label>Nouveau mot de passe :</label>
               </td>
               <td>
               <input type="password" name="newmdp1" placeholder="Mot de passe">
               </td>
            </tr>

            <tr>
               <td align="left">
               <label>Confirmation - nouveau mot de passe :</label>
               </td>

               <td>
               <input type="password" name="newmdp2" placeholder="Confirmation du mot de passe" />
               </td>
            </tr>

               </table>
               <br>
               <p style="text-align: center">
                <input type="submit" value="Mettre à jour mon profil !"> 
               </p>
            </form>
            <?php if(isset($msg)) { echo $msg; } ?>
                <form>
                <p style="text-align: center">
                <input type="button" value="Retour" onclick="history.go(-1)">
                </p>
                </form>
            </fieldset>
   
    <?php
    $editer_profil = ob_get_clean();
    return $editer_profil;
}
function ajoutercapteur($pieces){
    ob_start();
    if (count($pieces)>0) {
    ?>
         <h1>Ajouter des capteurs</h1>
         <br /><br />               
		 <fieldset>
         <form method="POST" action="http://localhost:8888/MySmartHouse%20-%20MVC/index.php?cible=ajoutercapteur">
                <table>
               <tr>
                  <td align="right">
                     <label for="n_piece">Nom de la pièce :</label>
                  </td>
                  <td>
                     <SELECT name="piece" size="1">
                        <?php
                        foreach ($pieces as $key => $value){
                            ?><OPTION value='<?=$value[0]?>'>Logement : <?=$value[1]?> => Piece : <?=$value[2]?> </OPTION><?php
                        }
                        ?>
                      </SELECT>
                   </td>
                </tr>

                <tr>
                  <td align="right">
                     <label for="type">Type de capteur :</label>
                  </td>
				  <td>
				  <SELECT name="type" size=1">
					<option selected>Lumière</option>
					<option>Température</option>
					<option>Humidité</option>
				  </select>
                  </td>
                </tr>

                <tr> 
                  <td align="right">
					<label for="n_piece">Numéro de série :</label>
                  </td>
                  <td>
                     <input type="text" placeholder="N° de série" id="nserie" name="nserie" >
                  </td>
                </tr>

                <tr>
                  <td></td>
                  <td align="center">
                     <br />
                        <input type="button" value="Retour" onclick="history.go(-1)"/>
                        <input type="submit" name="formcapteur" value="Valider" />
                  </td>
               </tr>
                </table>
            </form>
            </fieldset>
   
    <?php
    }
    else
        echo"<script>alert('Il faut créer des pièces avant de leur affecter des capteurs !');document.location.href='index.php?cible=ajouterpiece'</script>";
        
    $ajoutercapteur = ob_get_clean();
    return $ajoutercapteur;
}

function ajouterlogement(){
    ob_start();
    ?>
    <h1 style="text-align: center">EDITION DU LOGEMENT</h1>

         <br /><br />
         <form method="POST" action="http://localhost:8888/MySmartHouse%20-%20MVC/index.php?cible=ajouterlogement">
             <fieldset>
             <br>
                <table>
               <tr>
                  <td align="left">
                     <label for="nom">Nom du logement :</label>
                  </td>
                  <td>
                     <input type="text" placeholder="Nom du logement" id="nom" name="nom" value="" />
                  </td>
                </tr>

                <tr>
                  <td align="left">
                     <label for="superficie">Superficie :</label>
                  </td>
                  <td>
                     <input type="phone" placeholder="Superficie en m2" id="superficie" name="superficie" value="" />
                  </td>
                </tr>

                <tr>
                  <td align="left">
                     <label for="n_piece">Nombre de pièces :</label>
                  </td>
                  <td>
                     <input type="phone" placeholder="Nombre de pièces" id="n_piece" name="n_piece" value="" />
                  </td>
                </tr>

                <tr>
                  <td></td>
                  </table>
                  <br>
                  <p style="text-align: center">
                        <input type="button" value="Retour" onclick="history.go(-1)"/>
                        <input type="submit" name="formlogement" value="Valider" />
                  <p>
            </fieldset>

         </form>

    <?php
    $ajouterlogement = ob_get_clean();
    return $ajouterlogement;
}

function ajouterpiece($Logements){
    ob_start();
    if (count($Logements)>0) {
    ?>
        <h1 style="text-align: center">EDITION DE LA PIECE</h1>
        
         <br /><br />
         <form method="POST" action="http://localhost:8888/MySmartHouse%20-%20MVC/index.php?cible=ajouterpiece">
             <fieldset>
                <table>
                    
                <tr>
                  <td align="right">
                     <label for="n_logement">Nom du logement :</label>
                  </td>
                  <td>
                      <SELECT name="logement" size="1">
                        <?php
                        foreach ($Logements as $key => $value){
                            ?><OPTION value='<?=$value[0]?>'><?=$value[1]?></OPTION><?php
                        }
                        ?>
                      </SELECT>
                  </td>
                </tr>
    
               <tr>
                  <td align="right">
                     <label for="n_piece">Nom de la pièce :</label>
                  </td>
                  <td>
                     <input type="text" placeholder="Nom de la pièce" id="nom" name="nom" value="" />
                  </td>
                </tr>

                <tr>
                  <td align="right">
                     <label for="superficie">Superficie :</label>
                  </td>
                  <td>
                     <input type="phone" placeholder="Superficie en m2" id="superficie" name="superficie" value="" />
                  </td>
                </tr>
                <tr>
                    <td></td>
                  <td align="center">
                     <br />
                        <input type="button" value="Retour" onclick="history.go(-1)"/>
                        <input type="submit" name="formpiece" value="Valider" />
                  </td>
               </tr>
                </table>
            </fieldset>

         </form>



    <?php
    }
    else
        echo"<script>alert('Il faut créer des logements avant de leur affecter des pièces !!!');document.location.href='index.php?cible=ajouterlogement'</script>";
        
    $ajouterpiece = ob_get_clean();
    return $ajouterpiece;
}


?>