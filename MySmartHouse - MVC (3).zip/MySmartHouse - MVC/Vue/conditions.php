<?php
    include('commun.php');


    $entete = entete();
    $contenu = conditions();
    $pied = pied();

    include '../gabarit.php';
?>
