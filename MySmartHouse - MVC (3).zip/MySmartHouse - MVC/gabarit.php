<!DOCTYPE html>

<html>
    
    <head>
    
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<link rel="stylesheet" href="http://localhost:8888/MySmartHouse%20-%20MVC/Styles/Base.css" />
	<link rel="stylesheet" href="http://localhost:8888/MySmartHouse%20-%20MVC/Styles/structure7.css" />
        <title>
            <?php echo('MySmartHouse'); ?>
        </title>
    </head>
    
        <div id="global">
            
            <div id="tete">
                <?php echo($entete); ?>    
                <br>
            </div>
            
            <hr/>    
            
            <div id="corps">
                <br> 
                <div id="contenu">
                    <?php echo($contenu); ?>
                </div>
            </div>
            <br> <br> 
            <hr />    
    
            <div id="pied">
                <?php echo($pied); ?>
            </div>
        
        </div>
</html>