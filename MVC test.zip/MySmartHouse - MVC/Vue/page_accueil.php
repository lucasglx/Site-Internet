<?php
    $entete = entete("MySmartHouse / Accueil");
    $menu = menu();
    $contenu = "<h2>Contenu de l'accueil</h2>";
    $pied = pied();

    include 'gabarit.php';
?>

<?php
?>
 
        <br><br>
        <div class="imgtel">
         <center><p><img src="img/tel.jpg" alt="imgtel"></p></center>
         <center><p class="boutton_connexion"><a href="Connexion.php"><img src="img/button_connexion.png" alt="boutton_connexion" width="100px" height="30px"/></a><p></center>
         <p class="cadenas"><a href="Connexion.php"><img src="img/cadenas.jpg" alt="cadenas" width="100px" height="100px"/></a></p>
         </div>

        
    
    </body>
</html>
