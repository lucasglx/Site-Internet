<?php
    $entete = entete("MySmartHouse / Inscription");
    $contenu = inscription();
    $pied = pied();

    include 'gabarit.php';
?>