<?php
    include('commun.php');
    $titre = "MySmartHouse";

    $entete = entete();
    $contenu = FAQ();
    $pied = pied();

    include '../gabarit.php';
?>
