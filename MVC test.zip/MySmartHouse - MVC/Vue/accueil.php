<?php
    $titre = 'MySmartHouse';
    $entete = entete();
    $contenu = accueil_connecte();
    $pied = pied();

    include 'gabarit.php';
?>


