<?php
    include('commun.php');
    $titre = 'MySmartHouse';
    
    $entete = entete();
    $contenu = quisommesnous();
    $pied = pied();

    include '../gabarit.php';

?>
